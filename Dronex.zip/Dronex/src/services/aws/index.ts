export { DroneXRekognitionService } from './rekognition';
export { AWS_CONFIG } from './config';
